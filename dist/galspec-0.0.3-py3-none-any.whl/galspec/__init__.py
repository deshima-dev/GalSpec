from . import spectrumCreate

from .spectrumCreate import spectrum
from .spectrumCreate import plotspectrum